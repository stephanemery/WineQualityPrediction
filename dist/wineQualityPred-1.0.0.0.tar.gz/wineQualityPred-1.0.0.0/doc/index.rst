.. vim: set fileencoding=utf-8 :

.. _wine_quality:

Welcome to Wine quality prediction's documentation!
===================================================

.. toctree::
    :maxdepth: 2
    :caption: Contents:

Documentation
=============

.. toctree::

   installation
   guide
   troubleshooting
   api
	
	
Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
